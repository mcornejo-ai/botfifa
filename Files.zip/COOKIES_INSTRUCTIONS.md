# Instrucciones para exportar cookies de FIFA

## Paso 1: Instalá la extensión
- Chrome/Edge: **Cookie-Editor** (https://cookie-editor.com)
- Firefox: **Cookie-Editor** (misma extensión)

## Paso 2: Iniciá sesión en FIFA tickets
1. Abrí https://www.fifa.com/tickets
2. Loguéate con tu cuenta normalmente
3. Navegá hasta la página del Partido 86 (Argentina vs 2H)
4. Verificá que podés ver la información del partido

## Paso 3: Exportá las cookies
1. Con la pestaña de FIFA abierta, clickeá el ícono de Cookie-Editor
2. Clickeá **Export** → **Export as JSON**
3. Copiá el contenido
4. Pegalo en este archivo: `config/cookies.json`

## Paso 4: Para GitHub Actions (opcional)
Convertí el JSON a base64 para guardarlo como Secret:
```bash
base64 -i config/cookies.json | pbcopy   # Mac
base64 -w0 config/cookies.json           # Linux
```
Guardalo como Secret en GitHub con el nombre: `FIFA_COOKIES_B64`

## Formato esperado del cookies.json
```json
[
  {
    "name": "session_id",
    "value": "abc123...",
    "domain": ".fifa.com",
    "path": "/",
    "expires": 1751000000,
    "httpOnly": true,
    "secure": true
  },
  ...
]
```

## ⚠️ Importante
- Las cookies expiran. Si el monitor empieza a reportar bloqueos o errores 401/403,
  repetí el proceso de exportación.
- NUNCA subas cookies.json a un repositorio público.
- Agregá `config/cookies.json` a tu `.gitignore`.

## Renovación de cookies
Las sesiones de FIFA suelen durar entre 24hs y 7 días.
El monitor te avisará por Telegram cuando detecte un bloqueo o sesión expirada.
