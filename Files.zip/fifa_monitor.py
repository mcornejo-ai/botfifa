"""
FIFA World Cup 2026 - Monitor de Disponibilidad de Entradas
============================================================
URL real del sitio: fwc26-shop-usd.tickets.fifa.com
Plataforma: Secutix (sistema de ticketing de FIFA)

Comportamiento:
  - Una sola URL que contiene TODOS los partidos en el mismo HTML
  - Detecta el estado de cada partido por su ID (M86, etc.)
  - Señales exactas del HTML real: "Seleccionar" = disponible, "Actualmente no disponible" = sin stock
  - Envía alertas por Telegram cuando cambia el estado
  - Se detiene ante CAPTCHA / cola virtual / bloqueo

Restricciones:
  - Respeta robots.txt
  - Una sola sesión, sin paralelismo
  - Backoff exponencial ante errores
  - Intervalos conservadores (5-10 minutos)
"""

import os
import json
import time
import random
import logging
import hashlib
import datetime
import requests
from pathlib import Path
from typing import Optional
from urllib.robotparser import RobotFileParser


# ─────────────────────────────────────────────
# CONFIGURACIÓN CENTRAL
# ─────────────────────────────────────────────

CONFIG = {
    # URL única que contiene todos los partidos
    "base_url": "https://fwc26-shop-usd.tickets.fifa.com/secure/selection/event/date/product/10229225515651/lang/es",

    # Intervalos de chequeo (segundos)
    "check_interval_min": 300,   # 5 minutos
    "check_interval_max": 600,   # 10 minutos
    "backoff_base": 120,
    "backoff_max": 3600,
    "max_consecutive_errors": 5,

    # Telegram
    "telegram_bot_token": os.environ.get("TELEGRAM_BOT_TOKEN", ""),
    "telegram_chat_id":   os.environ.get("TELEGRAM_CHAT_ID", ""),

    # Paths
    "cookies_file": "config/cookies.json",
    "log_file":     "logs/history.jsonl",
    "state_file":   "logs/last_state.json",

    # User-agent de Chrome real
    "user_agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/126.0.0.0 Safari/537.36"
    ),

    # ── PARTIDOS A MONITOREAR ──────────────────────────────────────────
    # Identificados por el texto que aparece en el HTML del listado.
    # "match_label" es el texto exacto del partido en la página (ej: "M86").
    # "anchor_team" ayuda a localizar el bloque correcto si hay ambigüedad.
    # ──────────────────────────────────────────────────────────────────
    "matches": [
        {
            "id":           "M86",
            "name":         "Partido 86 – 1J vs 2H (Argentina si clasifica 1°)",
            "match_label":  "M86",
            "date":         "viernes 3 julio 2026",
            "time":         "18:00",
            "venue":        "Estadio de Miami",
            "price_usd":    "135.00",
            "priority":     True,
        },
    ],

    # Señales de bloqueo que detienen el monitor (texto en minúsculas)
    "block_signals": [
        "captcha",
        "queue-it",
        "waiting room",
        "sala de espera",
        "access denied",
        "cloudflare",
        "bot detected",
        "virtual queue",
        "too many requests",
        "estás en la fila",
        "please wait",
    ],

    # ── SEÑALES EXACTAS DEL HTML REAL DE SECUTIX/FIFA ─────────────────
    # Observadas en: fwc26-shop-usd.tickets.fifa.com
    # ──────────────────────────────────────────────────────────────────
    "availability_signals": {
        # Aparece el botón [Seleccionar] → hay stock
        "available_exact":    "[seleccionar]",
        # Texto de no disponibilidad
        "unavailable_exact":  "actualmente no disponible",
        "out_of_stock_exact": "this item is out of availability",
        # Disponibilidad limitada (también es comprable)
        "limited_exact":      "disponibilidad limitada",
    },
}


# ─────────────────────────────────────────────
# LOGGING
# ─────────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("logs/monitor.log", encoding="utf-8"),
    ],
)
log = logging.getLogger("fifa_monitor")


# ─────────────────────────────────────────────
# ROBOTS.TXT
# ─────────────────────────────────────────────

def can_fetch(url: str, user_agent: str) -> bool:
    try:
        from urllib.parse import urlparse
        parsed = urlparse(url)
        robots_url = f"{parsed.scheme}://{parsed.netloc}/robots.txt"
        rp = RobotFileParser()
        rp.set_url(robots_url)
        rp.read()
        allowed = rp.can_fetch(user_agent, url)
        if not allowed:
            log.warning(f"robots.txt bloquea: {url}")
        return allowed
    except Exception as e:
        log.warning(f"No se pudo leer robots.txt: {e}. Continuando con precaución.")
        return True


# ─────────────────────────────────────────────
# COOKIES
# ─────────────────────────────────────────────

def load_cookies(path: str) -> dict:
    cookies_path = Path(path)
    if not cookies_path.exists():
        log.warning(
            f"Sin cookies en {path}. Intentando sin autenticación.\n"
            "→ Exportá las cookies con Cookie-Editor desde tu browser logueado en fifa.com"
        )
        return {}

    with open(cookies_path, "r", encoding="utf-8") as f:
        raw = json.load(f)

    cookies = {}
    for c in raw:
        if isinstance(c, dict) and "name" in c and "value" in c:
            cookies[c["name"]] = c["value"]

    log.info(f"Cookies cargadas: {len(cookies)} entradas")
    return cookies


# ─────────────────────────────────────────────
# DETECCIÓN DE BLOQUEO
# ─────────────────────────────────────────────

def detect_block(response_text: str, status_code: int) -> Optional[str]:
    if status_code in (403, 429, 503):
        return f"HTTP {status_code}"
    text_lower = response_text.lower()
    for signal in CONFIG["block_signals"]:
        if signal in text_lower:
            return signal
    return None


# ─────────────────────────────────────────────
# EXTRACCIÓN DE ESTADO POR PARTIDO
# ─────────────────────────────────────────────

def extract_match_status(html: str, match: dict) -> dict:
    """
    Localiza el bloque del partido en el HTML y determina su estado.
    
    La página de Secutix/FIFA lista todos los partidos en un solo HTML.
    Cada partido tiene un bloque que incluye:
      - El ID del partido (ej: "M86")
      - El nombre del partido (ej: "Partido 86")
      - El estado: "Disponibilidad limitada" / "No disponible" / botón "Seleccionar"
    
    Estrategia: buscar el label del partido y luego analizar
    los ~2000 caracteres siguientes para detectar el estado.
    """
    label = match["match_label"]  # ej: "M86"
    html_lower = html.lower()
    sigs = CONFIG["availability_signals"]

    # Encontrar la posición del partido en el HTML
    # El formato es: "M86\n      Partido 86" o similar
    search_term = label.lower()
    pos = html_lower.find(f"\n{search_term}\n")
    if pos == -1:
        # Intentar variante sin salto de línea
        pos = html_lower.find(search_term)

    if pos == -1:
        log.warning(f"No se encontró '{label}' en el HTML.")
        return {
            "status": "NOT_FOUND",
            "signals_found": [],
            "page_hash": hashlib.md5(html.encode()).hexdigest(),
        }

    # Analizar los 3000 caracteres a partir del label del partido
    # (suficiente para cubrir el bloque completo de un partido)
    window = html_lower[pos:pos + 3000]

    status = "UNKNOWN"
    signals_found = []

    # Prioridad de detección:
    # 1. Botón [Seleccionar] presente → AVAILABLE
    # 2. "Disponibilidad limitada" → LIMITED (también comprable)
    # 3. "Actualmente no disponible" → UNAVAILABLE
    # 4. "This item is out of availability" → UNAVAILABLE

    if sigs["available_exact"] in window:
        status = "AVAILABLE"
        signals_found.append("botón [seleccionar] visible")

    if sigs["limited_exact"] in window:
        signals_found.append("disponibilidad limitada")
        if status != "AVAILABLE":
            status = "LIMITED"

    if sigs["unavailable_exact"] in window:
        signals_found.append("actualmente no disponible")
        if status not in ("AVAILABLE", "LIMITED"):
            status = "UNAVAILABLE"

    if sigs["out_of_stock_exact"] in window:
        signals_found.append("out of availability")
        if status not in ("AVAILABLE", "LIMITED"):
            status = "UNAVAILABLE"

    # Hash del bloque del partido (no de toda la página)
    # → detecta cambios específicos en ese partido
    block_hash = hashlib.md5(window.encode()).hexdigest()

    return {
        "status":      status,
        "signals_found": signals_found,
        "page_hash":   block_hash,
    }


# ─────────────────────────────────────────────
# TELEGRAM
# ─────────────────────────────────────────────

def send_telegram(message: str):
    token   = CONFIG["telegram_bot_token"]
    chat_id = CONFIG["telegram_chat_id"]

    if not token or not chat_id:
        log.warning("Telegram no configurado. Seteá TELEGRAM_BOT_TOKEN y TELEGRAM_CHAT_ID.")
        return

    url = f"https://api.telegram.org/bot{token}/sendMessage"
    payload = {
        "chat_id":                  chat_id,
        "text":                     message,
        "parse_mode":               "HTML",
        "disable_web_page_preview": False,
    }
    try:
        resp = requests.post(url, json=payload, timeout=10)
        if resp.status_code == 200:
            log.info("✅ Alerta Telegram enviada.")
        else:
            log.error(f"Error Telegram: {resp.status_code} - {resp.text}")
    except Exception as e:
        log.error(f"Error enviando Telegram: {e}")


def format_alert(match: dict, availability: dict) -> str:
    status_emoji = {
        "AVAILABLE":   "🟢",
        "LIMITED":     "🟡",
        "UNAVAILABLE": "🔴",
        "UNKNOWN":     "⚪",
        "NOT_FOUND":   "❓",
    }
    emoji  = status_emoji.get(availability["status"], "⚪")
    now    = datetime.datetime.now().strftime("%d/%m/%Y %H:%M:%S")
    url    = CONFIG["base_url"]
    priority_tag = "⭐ PRIORITARIO\n" if match.get("priority") else ""

    return (
        f"{emoji} <b>FIFA WC 2026 – DISPONIBILIDAD DETECTADA</b>\n\n"
        f"{priority_tag}"
        f"🏟 <b>{match['name']}</b>\n"
        f"📅 {match['date']} {match['time']} | {match['venue']}\n"
        f"💵 USD {match['price_usd']} (precio base)\n\n"
        f"Estado: <b>{availability['status']}</b>\n"
        f"Señales: {', '.join(availability['signals_found'])}\n\n"
        f"🔗 <a href='{url}'>Ver entradas en FIFA</a>\n"
        f"⏱ Detectado: {now}"
    )


# ─────────────────────────────────────────────
# ESTADO PERSISTENTE
# ─────────────────────────────────────────────

def load_state() -> dict:
    state_path = Path(CONFIG["state_file"])
    if state_path.exists():
        with open(state_path, "r") as f:
            return json.load(f)
    return {}


def save_state(state: dict):
    Path("logs").mkdir(exist_ok=True)
    with open(CONFIG["state_file"], "w") as f:
        json.dump(state, f, indent=2)


def log_event(match: dict, availability: dict):
    Path("logs").mkdir(exist_ok=True)
    event = {
        "timestamp":    datetime.datetime.now().isoformat(),
        "match_id":     match["id"],
        "match_name":   match["name"],
        "status":       availability["status"],
        "signals":      availability["signals_found"],
        "block_hash":   availability["page_hash"],
    }
    with open(CONFIG["log_file"], "a", encoding="utf-8") as f:
        f.write(json.dumps(event) + "\n")


# ─────────────────────────────────────────────
# REQUEST PRINCIPAL
# ─────────────────────────────────────────────

def fetch_page(session: requests.Session) -> Optional[requests.Response]:
    """Una sola request para obtener toda la página de partidos."""
    url = CONFIG["base_url"]

    if not can_fetch(url, CONFIG["user_agent"]):
        return None

    headers = {
        "User-Agent":                CONFIG["user_agent"],
        "Accept":                    "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language":           "es-AR,es;q=0.9,en;q=0.8",
        "Accept-Encoding":           "gzip, deflate, br",
        "Connection":                "keep-alive",
        "Upgrade-Insecure-Requests": "1",
        "Sec-Fetch-Dest":            "document",
        "Sec-Fetch-Mode":            "navigate",
        "Sec-Fetch-Site":            "none",
        "Cache-Control":             "no-cache",
    }

    try:
        log.info(f"Fetching: {url}")
        resp = session.get(url, headers=headers, timeout=25, allow_redirects=True)
        log.info(f"HTTP {resp.status_code} | {len(resp.text)} chars")
        return resp

    except requests.exceptions.Timeout:
        log.warning("Timeout al conectar con FIFA tickets.")
        return None
    except requests.exceptions.ConnectionError as e:
        log.warning(f"Error de conexión: {e}")
        return None


# ─────────────────────────────────────────────
# LOOP PRINCIPAL
# ─────────────────────────────────────────────

def run_monitor():
    log.info("=" * 60)
    log.info("🏆 FIFA WC 2026 Monitor iniciado")
    log.info(f"   Partidos monitoreados: {[m['id'] for m in CONFIG['matches']]}")
    log.info("=" * 60)

    # Cargar cookies
    cookies = load_cookies(CONFIG["cookies_file"])
    session = requests.Session()
    if cookies:
        session.cookies.update(cookies)

    state = load_state()
    consecutive_errors = 0
    blocked = False

    # Modo CI: una sola iteración (GitHub Actions)
    single_run = os.environ.get("CI_SINGLE_RUN", "false").lower() == "true"

    while not blocked:
        # ── Fetch único de toda la página ─────────────────────────────
        resp = fetch_page(session)

        if resp is None:
            consecutive_errors += 1
            if consecutive_errors >= CONFIG["max_consecutive_errors"]:
                log.error("Demasiados errores. Deteniendo monitor.")
                send_telegram("⚠️ Monitor FIFA detenido por errores de conexión repetidos.")
                break
            wait = min(CONFIG["backoff_base"] * (2 ** consecutive_errors), CONFIG["backoff_max"])
            log.info(f"Backoff: {wait}s")
            if single_run:
                break
            time.sleep(wait)
            continue

        # ── Detectar bloqueo ──────────────────────────────────────────
        block = detect_block(resp.text, resp.status_code)
        if block:
            log.warning(f"🚫 BLOQUEO: '{block}'. Deteniendo.")
            send_telegram(
                f"⚠️ <b>Monitor FIFA detenido</b>\n\n"
                f"Señal de bloqueo detectada: <code>{block}</code>\n\n"
                f"Acción: revisá la página manualmente y renová las cookies si es necesario.\n"
                f"🔗 <a href='{CONFIG['base_url']}'>Abrir sitio FIFA</a>"
            )
            blocked = True
            break

        consecutive_errors = 0

        # ── Analizar cada partido ─────────────────────────────────────
        html = resp.text
        for match in CONFIG["matches"]:
            availability = extract_match_status(html, match)
            log_event(match, availability)

            prev_status = state.get(match["id"], {}).get("status", "INIT")
            prev_hash   = state.get(match["id"], {}).get("block_hash", "")

            status_changed = availability["status"] != prev_status
            block_changed  = availability["page_hash"] != prev_hash

            log.info(
                f"  {match['id']}: {prev_status} → {availability['status']} "
                f"| {'CAMBIO' if status_changed else 'sin cambio'}"
            )

            # Alertar si:
            # a) Cambió a AVAILABLE o LIMITED (desde cualquier estado)
            # b) Ya estaba AVAILABLE y la página cambió (puede ser precio/categoría nueva)
            should_alert = (
                (status_changed and availability["status"] in ("AVAILABLE", "LIMITED"))
                or (availability["status"] == "AVAILABLE" and block_changed and prev_status == "AVAILABLE")
            )

            if should_alert:
                log.info(f"  🚨 ALERTA: {match['id']} → {availability['status']}")
                send_telegram(format_alert(match, availability))

            # Actualizar estado
            state[match["id"]] = {
                "status":     availability["status"],
                "block_hash": availability["page_hash"],
                "last_check": datetime.datetime.now().isoformat(),
            }

        save_state(state)

        if single_run:
            log.info("Modo CI: una iteración completada.")
            break

        # ── Esperar intervalo aleatorio ────────────────────────────────
        wait = random.randint(CONFIG["check_interval_min"], CONFIG["check_interval_max"])
        next_check = datetime.datetime.now() + datetime.timedelta(seconds=wait)
        log.info(f"Próximo chequeo: {next_check.strftime('%H:%M:%S')} (en {wait}s)\n")
        time.sleep(wait)

    log.info("Monitor detenido.")


# ─────────────────────────────────────────────
# ENTRY POINT
# ─────────────────────────────────────────────

if __name__ == "__main__":
    Path("logs").mkdir(exist_ok=True)
    Path("config").mkdir(exist_ok=True)
    run_monitor()
