# Configuración del Bot de Telegram

## Paso 1: Crear el bot
1. Abrí Telegram y buscá **@BotFather**
2. Enviá `/newbot`
3. Seguí las instrucciones:
   - Nombre del bot: `FIFA Monitor 2026`
   - Username: `fifa_monitor_tuapellido_bot` (debe ser único)
4. BotFather te dará un **token**: `123456789:ABCdef...`
   → Guardalo, lo necesitás como `TELEGRAM_BOT_TOKEN`

## Paso 2: Obtener tu Chat ID
1. Abrí Telegram y buscá **@userinfobot**
2. Enviá cualquier mensaje
3. Te responderá con tu ID numérico, ej: `987654321`
   → Guardalo como `TELEGRAM_CHAT_ID`

## Paso 3: Iniciar el bot
1. Buscá tu bot en Telegram (el username que elegiste)
2. Enviá `/start`
   (Necesario para que el bot pueda enviarte mensajes)

## Paso 4: Configurar variables de entorno

### Para correr localmente:
```bash
export TELEGRAM_BOT_TOKEN="123456789:ABCdef..."
export TELEGRAM_CHAT_ID="987654321"
python monitor/fifa_monitor.py
```

### Para GitHub Actions:
1. En tu repo: Settings → Secrets and variables → Actions
2. Agregá dos secrets:
   - `TELEGRAM_BOT_TOKEN` = el token del bot
   - `TELEGRAM_CHAT_ID` = tu ID de Telegram

## Mensaje de prueba
Para verificar que funciona antes de levantar el monitor:
```python
import requests
token = "TU_TOKEN"
chat_id = "TU_CHAT_ID"
url = f"https://api.telegram.org/bot{token}/sendMessage"
requests.post(url, json={"chat_id": chat_id, "text": "✅ Monitor FIFA configurado correctamente!"})
```

## Cómo se verá la alerta
```
🟢 FIFA WC 2026 – CAMBIO DETECTADO

🏟 Partido 86 – Argentina vs 2H
📅 2026-07-03 | Hard Rock Stadium, Miami

Estado: AVAILABLE
Señales: buy now, select tickets, usd

🔗 Ver entradas oficiales
⏱ Detectado: 03/07/2026 14:23:45
```
